-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 25, 2019 at 01:05 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `publinetis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` int(5) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `password`, `status`, `updated_at`, `created_at`) VALUES
(1, 'admin@gmail.com', 'admin', 'admin', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE `cms` (
  `id` int(5) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `status` int(5) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `interviewee_2`
--

CREATE TABLE `interviewee_2` (
  `id` int(5) NOT NULL,
  `name_wee` varchar(200) NOT NULL,
  `occupation_wee` varchar(200) NOT NULL,
  `email_wee` varchar(200) NOT NULL,
  `phone_wee` int(200) NOT NULL,
  `image_wee` varchar(200) NOT NULL,
  `notes_wee` text NOT NULL,
  `link_congress` varchar(200) NOT NULL,
  `link_image` varchar(200) NOT NULL,
  `iid` varchar(100) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `interviewer_1`
--

CREATE TABLE `interviewer_1` (
  `id` int(5) NOT NULL,
  `iid` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `media_outlet` varchar(200) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `comp_country` varchar(255) DEFAULT NULL,
  `mediaurl` varchar(255) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `traffic_of_site` varchar(200) DEFAULT NULL,
  `lang_of_site` varchar(200) DEFAULT NULL,
  `area_of_site` varchar(200) DEFAULT NULL,
  `lang_of_interview` varchar(200) DEFAULT NULL,
  `translate` varchar(200) DEFAULT NULL,
  `translate_lang` varchar(200) DEFAULT NULL,
  `notes` text,
  `deadline` varchar(255) NOT NULL,
  `interview_references` text,
  `resources` text,
  `image` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interviewer_1`
--

INSERT INTO `interviewer_1` (`id`, `iid`, `name`, `lname`, `occupation`, `email`, `phone`, `media_outlet`, `country`, `comp_country`, `mediaurl`, `website`, `traffic_of_site`, `lang_of_site`, `area_of_site`, `lang_of_interview`, `translate`, `translate_lang`, `notes`, `deadline`, `interview_references`, `resources`, `image`, `updated_at`, `created_at`) VALUES
(1, 'Wpjym089qJ', 'amit', 'shah', 'dfd', 'honda@gmail.com', '9545525458', '1212', 'India', 'India', 'test', 'ncode', 'sfsdfsdfd', 'english', 'aos', 'india', 'no', 'German', 'gggggggggggggggg', '06/24/2019', 'uy', 'yu', 'mahlati-mobile-sms.png', '2019-06-22 12:16:40', '2019-06-22 12:16:40'),
(7, 'PwKfQyWPyI', 'sfddsf', 'sdfsdf', 'sdfsdf', 'sandesh@gmail.com', '23432423423', 'blig test', 'test1', 'India', 'cnn.com', 'personal test', 'month traffice test', 'hindi', 'traffic test', 'english', 'no', 'Spanish', 'no', '07/25/2019', 'tr', 'er', 'mahlati-mobile-sms.png', '2019-06-24 12:14:06', '2019-06-24 12:14:06');

-- --------------------------------------------------------

--
-- Table structure for table `questions_3`
--

CREATE TABLE `questions_3` (
  `id` int(5) NOT NULL,
  `iid` varchar(200) NOT NULL,
  `question` text NOT NULL,
  `notes` text NOT NULL,
  `anwser` text NOT NULL,
  `notes_precious` text NOT NULL,
  `anwser_precious` text NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(5) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `updated_at`, `created_at`) VALUES
(1, 'service-1', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'service-2', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'service-3', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'service-4', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(5) NOT NULL,
  `title` varchar(200) NOT NULL,
  `value` varchar(200) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `ddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `status`, `ddate`, `updated_at`, `created_at`) VALUES
(2, 'a', 'b', 'honda@gmail.com', 'aakash', '123456', 'approved', '2019-05-27 17:30:17', '2019-05-27 17:30:17', '2019-05-27 17:30:17'),
(5, 'amit', 'kumar', 'amitkumar@gmail.com', 'amit', '123456', 'approved', '2019-05-28 15:57:24', '2019-05-28 15:57:24', '2019-05-28 15:57:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms`
--
ALTER TABLE `cms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interviewee_2`
--
ALTER TABLE `interviewee_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interviewer_1`
--
ALTER TABLE `interviewer_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions_3`
--
ALTER TABLE `questions_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cms`
--
ALTER TABLE `cms`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `interviewee_2`
--
ALTER TABLE `interviewee_2`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `interviewer_1`
--
ALTER TABLE `interviewer_1`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `questions_3`
--
ALTER TABLE `questions_3`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
