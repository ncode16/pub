-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 11, 2019 at 01:08 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `publinetis`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `title`, `description`, `updated_at`, `created_at`) VALUES
(1, 'About Us', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard.</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the .</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galleyLorem Ipsum is simply dummy text of the printing.</p>', '2019-08-26 12:09:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` int(5) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `password`, `status`, `updated_at`, `created_at`) VALUES
(1, 'admin@gmail1.com', 'admin', 'admin', 1, '2019-07-22 18:17:07', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE `cms` (
  `id` int(5) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `status` int(5) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `title`, `description`, `updated_at`, `created_at`) VALUES
(1, 'Contact Us', '<p>&lt;div style=&quot;float:left;width:49%;&quot;&gt;<br />\r\n&lt;iframe src=&quot;https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.801213046238!2d72.55756115015288!3d23.031069984874872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e84f53fffffff%3A0xa5680aa626bd4d43!2sNCode+Technologies%2C+Inc.!5e0!3m2!1sen!2sin!4v1563345518273!5m2!1sen!2sin&quot; width=&quot;400&quot; height=&quot;300&quot; frameborder=&quot;0&quot; style=&quot;border:0&quot; allowfullscreen&gt;&lt;/iframe&gt;<br />\r\n&lt;/div&gt;<br />\r\n&nbsp;</p>', '2019-11-11 12:42:02', '2019-07-17 11:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `interviewee_2`
--

CREATE TABLE `interviewee_2` (
  `id` int(5) NOT NULL,
  `name_wee` varchar(200) DEFAULT NULL,
  `surname_wee` varchar(255) DEFAULT NULL,
  `occupation_wee` varchar(200) DEFAULT NULL,
  `email_wee` varchar(200) DEFAULT NULL,
  `phone_wee` varchar(255) DEFAULT NULL,
  `image_wee` varchar(200) DEFAULT NULL,
  `notes_wee` text,
  `link_congress` varchar(200) DEFAULT NULL,
  `link_image` varchar(200) DEFAULT NULL,
  `iid` varchar(100) DEFAULT NULL,
  `facebook_page` varchar(255) DEFAULT NULL,
  `twitter_page` varchar(255) DEFAULT NULL,
  `linkedin_page` varchar(255) DEFAULT NULL,
  `instagram_page` varchar(255) DEFAULT NULL,
  `other_social_media_page` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interviewee_2`
--

INSERT INTO `interviewee_2` (`id`, `name_wee`, `surname_wee`, `occupation_wee`, `email_wee`, `phone_wee`, `image_wee`, `notes_wee`, `link_congress`, `link_image`, `iid`, `facebook_page`, `twitter_page`, `linkedin_page`, `instagram_page`, `other_social_media_page`, `updated_at`, `created_at`) VALUES
(4, 'rohit', 'gangani', 'ttttt', 'rohit@gmail.com', '1212121', '59a752c11e00001500c601e5.jpg', 'n1', 'c1', 'd', 'eedBPvYHUH', 'www.facebook.com', 'www.twitter.com', 'www.linkedin.com', 'www.instagram.com', 'www.google.com', '2019-07-23 11:37:41', '2019-07-23 11:37:41'),
(5, 't', 't', 't', 'test@gmail.com', NULL, NULL, NULL, NULL, NULL, 'osC4jvpAxR', NULL, NULL, NULL, NULL, NULL, '2019-10-12 17:17:18', '2019-10-12 17:17:18'),
(6, 'test', 'test', 'test', 'rohit@gmail.com', NULL, NULL, NULL, NULL, NULL, 'rZkV9qh7mp', NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:19:06', '2019-10-17 17:19:06'),
(7, 'rohit', 'gangani', 'ttttt', 'rohit@gmail.com', '1212121', '59a752c11e00001500c601e5.jpg', NULL, NULL, NULL, 'GrNkwPNxlB', NULL, NULL, NULL, NULL, NULL, '2019-10-21 11:56:39', '2019-10-21 11:56:39'),
(8, 'rohit', 'gangani', 'ttttt', 'rohit@gmail.com', '1212121', '59a752c11e00001500c601e5.jpg', NULL, NULL, NULL, 'jrPDLwSpqB', NULL, NULL, NULL, NULL, NULL, '2019-10-21 11:57:59', '2019-10-21 11:57:59'),
(9, 'rohit', 'gangani', 'ttttt', 'rohit@gmail.com', '1212121', '59a752c11e00001500c601e5.jpg', NULL, NULL, NULL, 'i8IeprYf7G', NULL, NULL, NULL, NULL, NULL, '2019-10-30 17:14:28', '2019-10-30 17:14:28'),
(10, 'rohit', 'gangani', 'ttttt', 'rohit@gmail.com', '1212121', '59a752c11e00001500c601e5.jpg', NULL, NULL, NULL, '10rijSvdBp', NULL, NULL, NULL, NULL, NULL, '2019-10-30 17:53:00', '2019-10-30 17:53:00');

-- --------------------------------------------------------

--
-- Table structure for table `interviewer_1`
--

CREATE TABLE `interviewer_1` (
  `id` int(5) NOT NULL,
  `iid` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `interview_with` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `media_outlet` varchar(200) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `comp_country` varchar(255) DEFAULT NULL,
  `mediaurl` varchar(255) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `traffic_of_site` varchar(200) DEFAULT NULL,
  `lang_of_site` varchar(200) DEFAULT NULL,
  `area_of_site` varchar(200) DEFAULT NULL,
  `lang_of_interview` varchar(200) DEFAULT NULL,
  `translate` varchar(200) DEFAULT NULL,
  `translate_lang` varchar(200) DEFAULT NULL,
  `notes` text,
  `deadline` varchar(255) NOT NULL,
  `interview_references` text,
  `resources` text,
  `image` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interviewer_1`
--

INSERT INTO `interviewer_1` (`id`, `iid`, `user_id`, `interview_with`, `name`, `lname`, `occupation`, `email`, `phone`, `media_outlet`, `country`, `comp_country`, `mediaurl`, `website`, `traffic_of_site`, `lang_of_site`, `area_of_site`, `lang_of_interview`, `translate`, `translate_lang`, `notes`, `deadline`, `interview_references`, `resources`, `image`, `updated_at`, `created_at`) VALUES
(12, 'jrPDLwSpqB', '', NULL, 'c cvb', 'cvcvbcvbcvbc', 'bcvbcvbcvb', 'test@g.c', '+666666666666', 'gfdgdfgdf', 'fgdfgdfg', 'fdgdfgdfg', 'gfdgfdg', 'fdgdfgdfgd', 'fgdfgdfg', 'dfgdfgdf', 'gfdgdfgdfg', 'gfdgdfgdf', 'yes', 'Portuguese', 'ggdfgdfgdfg', 'None', 'fdgdfgdfgd', 'fdgdfgdf', NULL, '2019-07-22 16:37:58', '2019-07-22 16:37:58'),
(15, 'eedBPvYHUH', '6', 'Rohit Gangani', 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', 'fdsfsdfsdfsdfsdf', 'fsdfsdf', 'India', 'fdsfsdfsdff', 'www.google.com', 'dsfsdf', 'sdfsdf', 'dfsdfsdf', 'sdfsdfsd', 'yes', 'Spanish', 'dsfsdfsdf', 'None', 'fdsfsdfsd', 'fdsfsdfsd', 'Screenshot from 2019-07-27 12:31:08.png', '2019-07-23 11:20:35', '2019-07-23 11:20:35'),
(17, 'GrNkwPNxlB', '', NULL, 'admin', 'admin', 'admin', 'admin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, NULL, '2019-08-27 12:56:35', '2019-08-27 12:56:35'),
(18, 'osC4jvpAxR', '6', 'T T', 'test', 'test', NULL, 'a1dmin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, '12/14/2019', NULL, NULL, NULL, '2019-10-12 17:16:54', '2019-10-12 17:16:54'),
(21, 'cWV6HkLDzQ', '6', NULL, 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', NULL, NULL, NULL, NULL, 'www.google.com', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, 'Screenshot from 2019-07-25 18:46:24.png', '2019-10-17 16:11:56', '2019-10-17 16:11:56'),
(22, 'CkxzIqaFxM', '6', NULL, 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', NULL, NULL, NULL, NULL, 'www.google.com', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, 'pianotunnittampere.png', '2019-10-17 16:12:36', '2019-10-17 16:12:36'),
(23, 'rZkV9qh7mp', '6', NULL, 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', NULL, NULL, NULL, NULL, 'www.google.com', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, 'pianotunnittampere.png', '2019-10-17 17:17:53', '2019-10-17 17:17:53'),
(24, 'i8IeprYf7G', '6', NULL, 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', NULL, NULL, NULL, NULL, 'www.google.com', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, 'pianotunnittampere.png', '2019-10-30 17:14:08', '2019-10-30 17:14:08'),
(25, '10rijSvdBp', '6', NULL, 'Rohit', 'Gangani', 'Occupation', 'rohit@ncodetechnologies.com', '1234567890', NULL, NULL, NULL, NULL, 'www.google.com', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, 'None', NULL, NULL, 'pianotunnittampere.png', '2019-10-30 17:52:45', '2019-10-30 17:52:45');

-- --------------------------------------------------------

--
-- Table structure for table `questions_3`
--

CREATE TABLE `questions_3` (
  `id` int(5) NOT NULL,
  `iid` varchar(200) DEFAULT NULL,
  `question` text,
  `notes` text,
  `anwser` text,
  `notes_precious` text,
  `anwser_precious` text,
  `interviewer_validate` varchar(5) DEFAULT NULL,
  `interviewee_validate` varchar(5) DEFAULT NULL,
  `lead_paragraph` text,
  `note_lead_paragraph` text,
  `final_text` text,
  `note_final_text` text,
  `interview_article` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `interview_website` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions_3`
--

INSERT INTO `questions_3` (`id`, `iid`, `question`, `notes`, `anwser`, `notes_precious`, `anwser_precious`, `interviewer_validate`, `interviewee_validate`, `lead_paragraph`, `note_lead_paragraph`, `final_text`, `note_final_text`, `interview_article`, `subtitle`, `interview_website`, `updated_at`, `created_at`) VALUES
(261, 'osC4jvpAxR', 'q1', 'n1', NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:36:11', '2019-10-17 17:36:11'),
(262, 'osC4jvpAxR', 'q2', 'n2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:36:11', '2019-10-17 17:36:11'),
(306, 'rZkV9qh7mp', 'rohit', 'rohit', NULL, NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:40:14', '2019-10-17 17:40:14'),
(307, 'rZkV9qh7mp', 't', 't', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:40:14', '2019-10-17 17:40:14'),
(336, 'jrPDLwSpqB', 'q1', 'n1', '', '', '', NULL, NULL, '1', '2', '3', '4', NULL, NULL, NULL, '2019-10-21 11:58:48', '2019-10-21 11:58:48'),
(337, 'jrPDLwSpqB', 'q2', 'n2', '', '', '', NULL, NULL, '1', '2', '3', '4', NULL, NULL, NULL, '2019-10-21 11:58:48', '2019-10-21 11:58:48'),
(490, 'i8IeprYf7G', 'q2', 'n2', 'a2', 'f2', 'af2', 'yes', 'yes', 'Lead', 'Note lead', 'Final text', 'Note final text', NULL, NULL, NULL, '2019-10-30 18:03:05', '2019-10-30 18:03:05'),
(491, 'i8IeprYf7G', 'q3', 'n3', 'a3', 'f3', 'af3', 'yes', 'yes', 'Lead', 'Note lead', 'Final text', 'Note final text', NULL, NULL, NULL, '2019-10-30 18:03:05', '2019-10-30 18:03:05'),
(492, 'i8IeprYf7G', 'q', 'n', 'a', 'f1', 'af1', 'yes', 'yes', 'Lead', 'Note lead', 'Final text', 'Note final text', NULL, NULL, NULL, '2019-10-30 18:03:06', '2019-10-30 18:03:06'),
(495, '10rijSvdBp', 'fsdfsdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-31 10:56:49', '2019-10-31 10:56:49'),
(496, '10rijSvdBp', 'dsfsdfsdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-31 10:56:49', '2019-10-31 10:56:49'),
(507, 'eedBPvYHUH', 'q2', 'n2.', 'a2', 'f1', 'af1', 'yes', NULL, 'Lead', 'Note lead', 'ft1', 'nt11', 'Title interview/article', 'Subtitle', 'URL or website where interview will be published', '2019-11-08 11:08:02', '2019-11-08 11:08:02'),
(508, 'eedBPvYHUH', 'q1?', 'n1', 'a1', 'f2', 'af2', 'yes', NULL, 'Lead', 'Note lead', 'ft1', 'nt11', 'Title interview/article', 'Subtitle', 'URL or website where interview will be published', '2019-11-08 11:08:02', '2019-11-08 11:08:02'),
(509, 'eedBPvYHUH', 'q3?', 'n3.', 'a3', 'f3', 'af3', 'yes', NULL, 'Lead', 'Note lead', 'ft1', 'nt11', 'Title interview/article', 'Subtitle', 'URL or website where interview will be published', '2019-11-08 11:08:03', '2019-11-08 11:08:03'),
(510, 'eedBPvYHUH', 'q5', 'n5', NULL, NULL, NULL, 'yes', NULL, 'Lead', 'Note lead', 'ft1', 'nt11', 'Title interview/article', 'Subtitle', 'URL or website where interview will be published', '2019-11-08 11:08:03', '2019-11-08 11:08:03'),
(511, 'eedBPvYHUH', 'q4?', 'n4.', 'a4', 'f4', 'af4', 'yes', NULL, 'Lead', 'Note lead', 'ft1', 'nt11', 'Title interview/article', 'Subtitle', 'URL or website where interview will be published', '2019-11-08 11:08:03', '2019-11-08 11:08:03');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(5) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `updated_at`, `created_at`) VALUES
(1, 'service-1', '<p>Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '2019-07-16 18:26:52', '0000-00-00 00:00:00'),
(2, 'service-2', '<p>Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '2019-08-26 12:09:03', '0000-00-00 00:00:00'),
(3, 'service-3', '<p>Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '2019-07-17 11:48:56', '0000-00-00 00:00:00'),
(4, 'service-4', '<p>Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '2019-07-17 11:49:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(5) NOT NULL,
  `title` varchar(200) NOT NULL,
  `value` varchar(200) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `website` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `status` varchar(15) NOT NULL,
  `ddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `occupation`, `phone`, `website`, `profile_pic`, `status`, `ddate`, `updated_at`, `created_at`) VALUES
(5, 'amit', 'kumar', 'amitkumar@gmail.com', 'amit', '123456', NULL, NULL, '', NULL, 'approved', '2019-05-28 15:57:24', '2019-05-28 15:57:24', '2019-05-28 15:57:24'),
(6, 'Rohit', 'Gangani', 'rohit@ncodetechnologies.com', 'rohit@ncodetechnologies.com', 'rohit', 'Occupation', '1234567890', 'www.google.com', '1024.png', 'approved', '2019-06-26 11:11:20', '2019-06-26 11:11:20', '2019-06-26 11:11:20'),
(7, 'test', 'test1', 'test@g.c', 'testuser', 'test@123', NULL, NULL, '', NULL, '', '0000-00-00 00:00:00', '2019-08-27 12:05:57', '2019-08-27 12:05:57'),
(8, 'abc', 'def', 'abc@gmail.com', '', '123456', NULL, NULL, '', NULL, 'approved', '2019-10-31 12:27:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'interviwer', 'interviwer', 'interviwer@gmail.com', '', '123456', NULL, NULL, '', NULL, 'approved', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-10-31 12:37:29');

-- --------------------------------------------------------

--
-- Table structure for table `user_interviewee`
--

CREATE TABLE `user_interviewee` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_interviewee`
--

INSERT INTO `user_interviewee` (`id`, `first_name`, `last_name`, `email`, `password`, `occupation`, `phone`, `website`, `profile_pic`, `status`, `updated_at`, `created_at`) VALUES
(2, 'rohit', 'gangani', 'rohit@gmail.com', '123456', 'ttttt', '1212121', NULL, '59a752c11e00001500c601e5.jpg', NULL, '2019-09-02 12:49:07', '2019-09-02 12:49:07'),
(3, 'test', 'test', 'test@gmail.com', 'test', NULL, NULL, NULL, NULL, NULL, '2019-10-17 17:33:37', '2019-10-17 17:33:37'),
(5, 'interviwee', 'interviwee', 'interviwee@gmail.com', '123456', NULL, NULL, NULL, NULL, 'approved', NULL, '2019-10-31 12:36:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms`
--
ALTER TABLE `cms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interviewee_2`
--
ALTER TABLE `interviewee_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interviewer_1`
--
ALTER TABLE `interviewer_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions_3`
--
ALTER TABLE `questions_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_interviewee`
--
ALTER TABLE `user_interviewee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cms`
--
ALTER TABLE `cms`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `interviewee_2`
--
ALTER TABLE `interviewee_2`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `interviewer_1`
--
ALTER TABLE `interviewer_1`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `questions_3`
--
ALTER TABLE `questions_3`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=512;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_interviewee`
--
ALTER TABLE `user_interviewee`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
